# Quick Setup Guide

## Step 1: Get OpenWeatherMap API Key

1. Visit https://openweathermap.org/api
2. Click "Sign Up" and create a free account
3. After signing up, go to https://home.openweathermap.org/api_keys
4. Generate a new API key (it may take a few minutes to activate)

## Step 2: Create .env File

In the root directory of this project, create a file named `.env` with the following content:

```
VITE_OPENWEATHER_API_KEY=your_actual_api_key_here
```

Replace `your_actual_api_key_here` with the API key you copied from OpenWeatherMap.

## Step 3: Install and Run

```bash
npm install
npm run dev
```

The app will start at `http://localhost:5173`

## Troubleshooting

### "API key not configured" error
- Make sure the `.env` file is in the root directory (same level as `package.json`)
- Restart the dev server after creating/modifying the `.env` file
- Make sure the variable name starts with `VITE_` (required for Vite)

### "City not found" error
- Check the spelling of the city name
- Try using format: "City, Country Code" (e.g., "Paris, FR")

### Location permission denied
- Make sure you're using HTTPS or localhost
- Check browser settings to allow location access
- You can always search for a city manually

