# Weather App

A beautiful, modern weather application built with React, TypeScript, and Tailwind CSS. Get real-time weather information for any city or use your current location.

## Features

- 🌍 Search weather by city name
- 📍 Get weather for your current location
- 🌤️ Detailed weather information (temperature, humidity, wind speed, pressure, visibility)
- 🌅 Sunrise and sunset times
- 🎨 Beautiful, modern UI with glassmorphism design
- 📱 Responsive design that works on all devices

## Setup Instructions

### 1. Get an OpenWeatherMap API Key

1. Go to [OpenWeatherMap](https://openweathermap.org/api)
2. Sign up for a free account
3. Navigate to the API keys section
4. Copy your API key

### 2. Configure Environment Variables

Create a `.env` file in the root directory:

```env
VITE_OPENWEATHER_API_KEY=your_api_key_here
```

**Important:** Replace `your_api_key_here` with your actual OpenWeatherMap API key.

### 3. Install Dependencies

```bash
npm install
```

### 4. Run the Development Server

```bash
npm run dev
```

The app will be available at `http://localhost:5173` (or the port shown in your terminal).

## Optional: Supabase Configuration

If you prefer to use Supabase Edge Functions instead of direct API calls, you can configure Supabase:

1. Set up a Supabase project
2. Deploy the edge function from `supabase/functions/weather/index.ts`
3. Set the following environment variables:

```env
VITE_SUPABASE_URL=your_supabase_url
VITE_SUPABASE_ANON_KEY=your_supabase_anon_key
OPENWEATHER_API_KEY=your_api_key_here
```

The app will automatically try to use Supabase if configured, and fall back to direct API calls if Supabase is unavailable.

## Usage

1. **Search by City**: Enter a city name in the search bar and press Enter
2. **Use Current Location**: Click the location pin icon to get weather for your current location

## Technologies Used

- React 18
- TypeScript
- Vite
- Tailwind CSS
- Lucide React (icons)
- OpenWeatherMap API

## Project Structure

```
├── src/
│   ├── components/          # React components
│   │   ├── ErrorMessage.tsx
│   │   ├── LoadingSpinner.tsx
│   │   ├── SearchBar.tsx
│   │   └── WeatherCard.tsx
│   ├── services/            # API services
│   │   └── weatherService.ts
│   ├── App.tsx              # Main app component
│   ├── main.tsx             # App entry point
│   └── index.css            # Global styles
├── supabase/
│   └── functions/           # Supabase edge functions (optional)
│       └── weather/
└── package.json
```

## Troubleshooting

### API Key Issues
- Make sure your `.env` file is in the root directory
- Restart the dev server after adding/changing environment variables
- Verify your API key is correct at OpenWeatherMap

### Location Permission Issues
- Make sure your browser allows location access
- Use HTTPS or localhost (geolocation requires secure context)
- Check browser settings for location permissions

### City Not Found
- Check the spelling of the city name
- Try using the format: "City, Country Code" (e.g., "London, GB")

## License

MIT

