import { AlertCircle } from 'lucide-react';

interface ErrorMessageProps {
  message: string;
}

export const ErrorMessage = ({ message }: ErrorMessageProps) => {
  return (
    <div className="bg-red-500/10 backdrop-blur-lg border border-red-500/30 rounded-2xl p-6 max-w-md">
      <div className="flex items-center gap-3">
        <AlertCircle className="w-6 h-6 text-red-400 flex-shrink-0" />
        <p className="text-white">{message}</p>
      </div>
    </div>
  );
};
