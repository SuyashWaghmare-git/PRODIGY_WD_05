import { WeatherData } from '../services/weatherService';
import { Droplets, Wind, Eye, Gauge, Sunrise, Sunset } from 'lucide-react';

interface WeatherCardProps {
  weather: WeatherData;
}

export const WeatherCard = ({ weather }: WeatherCardProps) => {
  const formatTime = (timestamp: number) => {
    return new Date(timestamp * 1000).toLocaleTimeString('en-US', {
      hour: '2-digit',
      minute: '2-digit',
    });
  };

  return (
    <div className="w-full max-w-4xl">
      <div className="bg-white/10 backdrop-blur-lg border border-white/20 rounded-3xl p-8 shadow-2xl">
        <div className="flex flex-col md:flex-row items-center justify-between mb-8">
          <div className="text-center md:text-left mb-6 md:mb-0">
            <h2 className="text-5xl font-bold text-white mb-2">
              {weather.location}
            </h2>
            <p className="text-2xl text-white/70">{weather.country}</p>
          </div>

          <div className="flex items-center gap-4">
            <img
              src={`https://openweathermap.org/img/wn/${weather.icon}@4x.png`}
              alt={weather.description}
              className="w-32 h-32 drop-shadow-2xl"
            />
            <div>
              <div className="text-7xl font-bold text-white">
                {Math.round(weather.temperature)}°
              </div>
              <p className="text-xl text-white/70 capitalize mt-2">
                {weather.description}
              </p>
            </div>
          </div>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
          <WeatherDetail
            icon={<Droplets className="w-6 h-6" />}
            label="Humidity"
            value={`${weather.humidity}%`}
          />
          <WeatherDetail
            icon={<Wind className="w-6 h-6" />}
            label="Wind Speed"
            value={`${weather.windSpeed} m/s`}
          />
          <WeatherDetail
            icon={<Gauge className="w-6 h-6" />}
            label="Pressure"
            value={`${weather.pressure} hPa`}
          />
          <WeatherDetail
            icon={<Eye className="w-6 h-6" />}
            label="Visibility"
            value={`${(weather.visibility / 1000).toFixed(1)} km`}
          />
          <WeatherDetail
            icon={<Sunrise className="w-6 h-6" />}
            label="Sunrise"
            value={formatTime(weather.sunrise)}
          />
          <WeatherDetail
            icon={<Sunset className="w-6 h-6" />}
            label="Sunset"
            value={formatTime(weather.sunset)}
          />
        </div>

        <div className="mt-6 pt-6 border-t border-white/20">
          <p className="text-white/70 text-center">
            Feels like <span className="text-white font-semibold">{Math.round(weather.feelsLike)}°C</span>
          </p>
        </div>
      </div>
    </div>
  );
};

interface WeatherDetailProps {
  icon: React.ReactNode;
  label: string;
  value: string;
}

const WeatherDetail = ({ icon, label, value }: WeatherDetailProps) => {
  return (
    <div className="bg-white/5 backdrop-blur-sm border border-white/10 rounded-2xl p-4 hover:bg-white/10 transition-all duration-300">
      <div className="flex items-center gap-3 mb-2 text-white/70">
        {icon}
        <span className="text-sm">{label}</span>
      </div>
      <div className="text-2xl font-semibold text-white">{value}</div>
    </div>
  );
};
