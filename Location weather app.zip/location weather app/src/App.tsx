import { useState, useEffect } from 'react';
import { Cloud } from 'lucide-react';
import { SearchBar } from './components/SearchBar';
import { WeatherCard } from './components/WeatherCard';
import { LoadingSpinner } from './components/LoadingSpinner';
import { ErrorMessage } from './components/ErrorMessage';
import {
  WeatherData,
  getCurrentLocation,
  getWeatherByCoordinates,
  getWeatherByCity,
} from './services/weatherService';

function App() {
  const [weather, setWeather] = useState<WeatherData | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    handleGetLocation();
  }, []);

  const handleGetLocation = async () => {
    setIsLoading(true);
    setError(null);

    try {
      const coords = await getCurrentLocation();
      const weatherData = await getWeatherByCoordinates(coords.lat, coords.lon);
      setWeather(weatherData);
    } catch (err) {
      if (err instanceof Error) {
        setError(err.message);
      } else {
        setError('Unable to get your location. Please search for a city instead.');
      }
    } finally {
      setIsLoading(false);
    }
  };

  const handleSearch = async (city: string) => {
    setIsLoading(true);
    setError(null);

    try {
      const weatherData = await getWeatherByCity(city);
      setWeather(weatherData);
    } catch (err) {
      if (err instanceof Error) {
        setError(err.message);
      } else {
        setError('Unable to fetch weather data. Please try again.');
      }
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 via-black to-gray-900 flex flex-col items-center justify-center p-6 relative overflow-hidden">
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_50%_50%,rgba(17,24,39,0.8),rgba(0,0,0,1))] pointer-events-none"></div>

      <div className="absolute top-0 left-0 w-full h-full overflow-hidden pointer-events-none">
        <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-blue-500/10 rounded-full blur-3xl"></div>
        <div className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-slate-500/10 rounded-full blur-3xl"></div>
      </div>

      <div className="relative z-10 w-full max-w-6xl flex flex-col items-center">
        <div className="flex items-center gap-3 mb-8">
          <Cloud className="w-12 h-12 text-white" />
          <h1 className="text-5xl font-bold text-white">Weather App</h1>
        </div>

        <SearchBar
          onSearch={handleSearch}
          onGetLocation={handleGetLocation}
          isLoading={isLoading}
        />

        {isLoading && <LoadingSpinner />}

        {error && !isLoading && <ErrorMessage message={error} />}

        {weather && !isLoading && !error && <WeatherCard weather={weather} />}

        {!weather && !isLoading && !error && (
          <div className="text-center text-white/70">
            <p className="text-xl">Search for a city or use your current location</p>
            <p className="text-sm mt-2">to see the weather forecast</p>
          </div>
        )}
      </div>
    </div>
  );
}

export default App;
