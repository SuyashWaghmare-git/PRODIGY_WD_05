// Get API key from environment or use a fallback
const OPENWEATHER_API_KEY = import.meta.env.VITE_OPENWEATHER_API_KEY || '';

// Debug: Log if API key is loaded (remove in production)
if (import.meta.env.DEV) {
  console.log('API Key loaded:', OPENWEATHER_API_KEY ? 'Yes' : 'No - Please check .env file');
  if (OPENWEATHER_API_KEY) {
    console.log('API Key length:', OPENWEATHER_API_KEY.length, 'characters');
    console.log('API Key (first 8 + last 4):', OPENWEATHER_API_KEY.substring(0, 8) + '...' + OPENWEATHER_API_KEY.slice(-4));
  }
}

// Optional: Supabase configuration (for edge function alternative)
const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
const anonKey = import.meta.env.VITE_SUPABASE_ANON_KEY;
const useSupabase = supabaseUrl && anonKey;

export interface WeatherData {
  location: string;
  country: string;
  temperature: number;
  feelsLike: number;
  description: string;
  humidity: number;
  windSpeed: number;
  pressure: number;
  icon: string;
  sunrise: number;
  sunset: number;
  visibility: number;
}

export interface Coordinates {
  lat: number;
  lon: number;
}

export const getCurrentLocation = (): Promise<Coordinates> => {
  return new Promise((resolve, reject) => {
    if (!navigator.geolocation) {
      reject(new Error('Geolocation is not supported by your browser'));
      return;
    }

    navigator.geolocation.getCurrentPosition(
      (position) => {
        resolve({
          lat: position.coords.latitude,
          lon: position.coords.longitude,
        });
      },
      (error) => {
        let errorMessage = 'Unable to get your location.';
        if (error.code === error.PERMISSION_DENIED) {
          errorMessage = 'Location access denied. Please enable location permissions.';
        } else if (error.code === error.POSITION_UNAVAILABLE) {
          errorMessage = 'Location information is unavailable.';
        } else if (error.code === error.TIMEOUT) {
          errorMessage = 'Location request timed out.';
        }
        reject(new Error(errorMessage));
      }
    );
  });
};

const fetchFromSupabase = async (url: string): Promise<any> => {
  const response = await fetch(url, {
    headers: {
      Authorization: `Bearer ${anonKey}`,
      'Content-Type': 'application/json',
    },
  });

  if (!response.ok) {
    const errorData = await response.json().catch(() => ({}));
    throw new Error(errorData.error || 'Failed to fetch weather data');
  }

  return response.json();
};

const fetchFromOpenWeather = async (url: string): Promise<any> => {
  const response = await fetch(url);

  if (!response.ok) {
    const errorData = await response.json().catch(() => ({}));
    if (response.status === 401) {
      throw new Error(
        'Invalid API key. Please verify:\n' +
        '1. Your API key is correct (32 characters)\n' +
        '2. The key has been activated (may take 10-60 minutes after creation)\n' +
        '3. Check your API key at: https://home.openweathermap.org/api_keys'
      );
    }
    if (response.status === 404) {
      throw new Error('City not found. Please check the spelling and try again.');
    }
    throw new Error(errorData.message || 'Failed to fetch weather data');
  }

  return response.json();
};

export const getWeatherByCoordinates = async (
  lat: number,
  lon: number
): Promise<WeatherData> => {
  try {
    let data;
    
    if (useSupabase) {
      // Try Supabase edge function first
      try {
        const url = `${supabaseUrl}/functions/v1/weather?lat=${lat}&lon=${lon}`;
        data = await fetchFromSupabase(url);
      } catch (supabaseError) {
        // Fallback to direct API if Supabase fails
        if (!OPENWEATHER_API_KEY) {
          throw new Error('API key not configured. Please add VITE_OPENWEATHER_API_KEY to your .env file.');
        }
        const url = `https://api.openweathermap.org/data/2.5/weather?lat=${lat}&lon=${lon}&units=metric&appid=${OPENWEATHER_API_KEY}`;
        data = await fetchFromOpenWeather(url);
      }
    } else {
      // Use direct OpenWeatherMap API
      if (!OPENWEATHER_API_KEY) {
        throw new Error('API key not configured. Please add VITE_OPENWEATHER_API_KEY to your .env file.');
      }
      const url = `https://api.openweathermap.org/data/2.5/weather?lat=${lat}&lon=${lon}&units=metric&appid=${OPENWEATHER_API_KEY}`;
      data = await fetchFromOpenWeather(url);
    }

    return formatWeatherData(data);
  } catch (error) {
    if (error instanceof Error) {
      throw error;
    }
    throw new Error('Unable to fetch weather data. Please try again.');
  }
};

export const getWeatherByCity = async (city: string): Promise<WeatherData> => {
  try {
    let data;
    
    if (useSupabase) {
      // Try Supabase edge function first
      try {
        const url = `${supabaseUrl}/functions/v1/weather?city=${encodeURIComponent(city)}`;
        data = await fetchFromSupabase(url);
      } catch (supabaseError) {
        // Fallback to direct API if Supabase fails
        if (!OPENWEATHER_API_KEY) {
          throw new Error('API key not configured. Please add VITE_OPENWEATHER_API_KEY to your .env file.');
        }
        const url = `https://api.openweathermap.org/data/2.5/weather?q=${encodeURIComponent(city)}&units=metric&appid=${OPENWEATHER_API_KEY}`;
        data = await fetchFromOpenWeather(url);
      }
    } else {
      // Use direct OpenWeatherMap API
      if (!OPENWEATHER_API_KEY) {
        throw new Error('API key not configured. Please add VITE_OPENWEATHER_API_KEY to your .env file.');
      }
      const url = `https://api.openweathermap.org/data/2.5/weather?q=${encodeURIComponent(city)}&units=metric&appid=${OPENWEATHER_API_KEY}`;
      data = await fetchFromOpenWeather(url);
    }

    return formatWeatherData(data);
  } catch (error) {
    if (error instanceof Error) {
      throw error;
    }
    throw new Error('Unable to fetch weather data. Please try again.');
  }
};

const formatWeatherData = (data: any): WeatherData => {
  if (!data || !data.main || !data.weather || !data.weather[0] || !data.sys) {
    throw new Error('Invalid weather data received from API');
  }

  // Preserve full precision from API (no early rounding)
  // Temperature comes in Celsius from OpenWeatherMap API with units=metric
  // Store with full decimal precision for accurate calculations
  const temp = data.main.temp;
  const feelsLikeTemp = data.main.feels_like;

  return {
    location: data.name || 'Unknown',
    country: data.sys.country || '',
    temperature: temp,
    feelsLike: feelsLikeTemp,
    description: data.weather[0].description || 'N/A',
    humidity: data.main.humidity || 0,
    windSpeed: data.wind?.speed || 0,
    pressure: data.main.pressure || 0,
    icon: data.weather[0].icon || '01d',
    sunrise: data.sys.sunrise || 0,
    sunset: data.sys.sunset || 0,
    visibility: data.visibility !== undefined ? data.visibility : 10000, // Default visibility in meters
  };
};
